# Based on the original DreamHost deploy.rb recipe
#
# This deploy recipe will deploy a project from a GitHub repo to a Dreamhost server
#
# GitHub settings #######################################################################################
default_run_options[:pty] = true
set :repository,  "git@github.com:swagner2/corp_website_radiant.git" #GitHub clone URL
set :scm, "git"
set :scm_passphrase, "" # This is the passphrase for the ssh key on the server deployed to
set :git_enable_submodules, 1
set :branch, "master"
set :scm_verbose, true

# Dreamhost Settings #####################################################################################
set :user, 'ditoby' # Dreamhost username
set :domain, 'greengoblin.dreamhost.com'  # Dreamhost servername where your account is located
set :project, 'corp_website_radiant'  # Your application as its called in the repository
set :application, 'dealerignition.com'  # Your app's location (domain or sub-domain name as setup in panel)
set :applicationdir, "/home/#{user}/#{application}"  # The standard Dreamhost setup

set :rails_env, 'production'

set :keep_releases, 1

# Don't change this stuff, but you may want to set shared files at the end of the file ##################
# deploy config
set :deploy_to, applicationdir
set :deploy_via, :remote_cache

# roles (servers)
role :app, domain
role :web, domain
role :db,  domain, :primary => true

namespace :deploy do
 [:start, :stop, :finalize_update, :migrate, :migrations, :cold].each do |t|
   desc "#{t} task is a no-op with mod_rails"
   task t, :roles => :app do ; end
  end

  desc "Restart Passenger"
  task :restart, :roles => :app do
    run "touch #{current_path}/tmp/restart.txt"
  end

end

# additional settings
#default_run_options[:pty] = true  # Forgo errors when deploying from windows
#ssh_options[:keys] = %w(/Path/To/id_rsa)            # If you are using ssh_keys
#set :chmod755, "app config db lib public vendor script script/* public/disp*"
set :use_sudo, false

# Optional tasks ##########################################################################################
# for use with shared files (e.g. config files)
after "deploy:update_code" do
  run "mkdir #{release_path}/tmp"
  run "rm -f #{release_path}/config/database.yml"
  run "ln -s #{shared_path}/database.yml #{release_path}/config/"
end
